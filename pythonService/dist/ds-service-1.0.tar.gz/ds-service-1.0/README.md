# ds-service

A backend service for processing messages and integrating with Kafka, built with Flask.

## Installation

See requirements.txt for dependencies.

## Usage

Run the Flask app as described in the source code.
